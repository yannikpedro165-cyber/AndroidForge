package com.headshotpro;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 14, 20);
    private final int PANEL = Color.rgb(20, 30, 42);
    private final int GREEN = Color.rgb(86, 245, 174);
    private final int MUTED = Color.rgb(166, 183, 200);
    private LinearLayout root, valuesBox;
    private TextView status;
    private int[] values = {195, 190, 180, 165, 100, 180, 52};
    private String[] labels = {"Geral", "Ponto vermelho", "Mira 2x", "Mira 4x", "Mira de precisão", "Câmara livre", "Botão de tiro (%)"};

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUI();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void pad(View v, int p) { v.setPadding(p,p,p,p); }
    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = column(); root.setBackgroundColor(BG); root.setPadding(20,24,20,24);
        scroll.addView(root); setContentView(scroll);

        LinearLayout header = row();
        TextView logo = text("◎", 42, GREEN, true);
        logo.setGravity(Gravity.CENTER); logo.setBackground(bg(PANEL, 24));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(74,74); lp.setMargins(0,0,14,0); header.addView(logo,lp);
        LinearLayout titles = column();
        titles.addView(text("HEADSHOT PRO", 23, GREEN, true));
        titles.addView(text("FREE FIRE MAX • INFINIX HOT 40i", 11, MUTED, true));
        header.addView(titles, new LinearLayout.LayoutParams(0,-2,1));
        root.addView(header);
        addSpace(22);

        TextView subtitle = text("PERFIL ÚNICO • SENSIBILIDADE RÁPIDA", 14, Color.WHITE, true);
        root.addView(subtitle); addSpace(12);
        TextView note = text("Valores iniciais para testar. Ajusta conforme o teu controlo e a versão do jogo.", 13, MUTED, false);
        note.setLineSpacing(3,1); root.addView(note); addSpace(16);

        valuesBox = column(); valuesBox.setBackground(bg(PANEL,24)); valuesBox.setPadding(16,16,16,10);
        root.addView(valuesBox);
        renderValues();

        addSpace(18);
        Button copy = button("COPIAR CONFIGURAÇÕES");
        copy.setOnClickListener(v -> copySettings()); root.addView(copy);
        addSpace(10);
        Button reset = button("RESTAURAR PERFIL INICIAL");
        reset.setBackground(bg(Color.rgb(35,47,61),18));
        reset.setOnClickListener(v -> { values = new int[]{195,190,180,165,100,180,52}; renderValues(); status.setText("Perfil inicial restaurado."); });
        root.addView(reset);
        addSpace(12);
        status = text("Pronto para configurar manualmente no jogo.", 12, GREEN, false);
        root.addView(status); addSpace(16);
        TextView warning = text("IMPORTANTE\nEste painel não modifica o Free Fire MAX nem oferece mira automática. Copia os valores e introduz manualmente nas definições do jogo. As opções disponíveis podem variar conforme a versão.", 12, MUTED, false);
        warning.setLineSpacing(4,1); warning.setBackground(bg(Color.rgb(16,29,27),18)); warning.setPadding(14,14,14,14);
        root.addView(warning);
    }
    private void renderValues() {
        valuesBox.removeAllViews();
        for (int i=0; i<labels.length; i++) {
            final int index = i;
            LinearLayout line = row();
            TextView label = text(labels[i], 14, Color.WHITE, false);
            line.addView(label, new LinearLayout.LayoutParams(0,-2,1));
            TextView val = text(String.valueOf(values[i]), 17, GREEN, true);
            val.setGravity(Gravity.RIGHT); line.addView(val);
            valuesBox.addView(line); 
            SeekBar seek = new SeekBar(this);
            seek.setMax(i == 6 ? 70 : 200);
            seek.setProgress(values[i]);
            if (i == 6) seek.setMin(35);
            seek.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));
            seek.setThumbTintList(android.content.res.ColorStateList.valueOf(GREEN));
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                    values[index] = progress;
                    val.setText(String.valueOf(progress));
                    status.setText("Configuração alterada. Copia para guardar.");
                }
                public void onStartTrackingTouch(SeekBar sb) {}
                public void onStopTrackingTouch(SeekBar sb) {}
            });
            valuesBox.addView(seek);
            View spacer = new View(this);
            valuesBox.addView(spacer, new LinearLayout.LayoutParams(1,8));
        }
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(BG);
        b.setTextSize(13); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setAllCaps(false); b.setBackground(bg(GREEN,18));
        return b;
    }
    private void copySettings() {
        StringBuilder s = new StringBuilder("HEADSHOT PRO — FREE FIRE MAX — INFINIX HOT 40i\n");
        for(int i=0;i<labels.length;i++) s.append(labels[i]).append(": ").append(values[i]).append(i==6?"%":"").append("\n");
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Headshot Pro", s.toString()));
        status.setText("Configurações copiadas para a área de transferência.");
        Toast.makeText(this,"Configurações copiadas!",Toast.LENGTH_SHORT).show();
    }
    private void addSpace(int h) {
        View v = new View(this); root.addView(v,new LinearLayout.LayoutParams(1,h));
    }
}
