# Headshot Pro — Android

Projeto Android nativo em Java, para abrir e compilar no Android Studio.

## Funcionalidades
- Perfil inicial único para Free Fire MAX / Infinix Hot 40i
- Controlos deslizantes para sensibilidades e tamanho do botão de tiro
- Copiar configuração para a área de transferência
- Restaurar perfil inicial
- Interface escura com destaque verde

## Como gerar o APK
1. Instale o Android Studio num computador.
2. Abra a pasta `HeadshotPro` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se necessário, instale Android SDK 35.
5. Use **Build > Build APK(s)**.
6. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

Este projeto não inclui cheats nem interage automaticamente com o jogo. Os valores são sugestões para aplicação manual e podem precisar de ajuste.
