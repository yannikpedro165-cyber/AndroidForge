package mz.xiterpro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    int bg = Color.rgb(5, 8, 20), panel = Color.rgb(13, 20, 37);
    int green = Color.rgb(0, 235, 125), cyan = Color.rgb(0, 210, 255);
    LinearLayout root, content;
    TextView status;
    int sessionSeconds = 60;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        root = new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(bg);
        TextView header = new TextView(this);
        header.setText("⚡ XITER PRO\nINFINIX HOT 40i • FREE FIRE");
        header.setTextColor(green); header.setTextSize(23); header.setTypeface(null, Typeface.BOLD);
        header.setGravity(Gravity.CENTER); header.setPadding(12,22,12,18); root.addView(header);
        HorizontalScrollView tabs = new HorizontalScrollView(this);
        LinearLayout tabrow = new LinearLayout(this);
        String[] names = {"Início","Treino de capa","Desempenho","Sensibilidade"};
        for (String n : names) { Button btn = new Button(this); btn.setText(n); btn.setTextColor(Color.WHITE); btn.setOnClickListener(v -> show(n)); tabrow.addView(btn); }
        tabs.addView(tabrow); root.addView(tabs);
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setPadding(16,10,16,24); content.setOrientation(1);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); show("Início");
    }
    GradientDrawable shape(int color) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(24); d.setStroke(1, green); return d; }
    void card(String title, String body) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(1); box.setPadding(16,14,16,14); box.setBackground(shape(panel));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8); content.addView(box,p);
        TextView t = new TextView(this); t.setText(title); t.setTextColor(green); t.setTextSize(18); t.setTypeface(null,Typeface.BOLD); box.addView(t);
        TextView b = new TextView(this); b.setText(body); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setPadding(0,8,0,0); box.addView(b);
    }
    void button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.BLACK); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        b.setOnClickListener(v -> action.run()); content.addView(b,new LinearLayout.LayoutParams(-1,-2));
    }
    void show(String page) {
        content.removeAllViews();
        if(page.equals("Início")) {
            card("PAINEL PRONTO", "Ferramentas de treino e recomendações para o Infinix Hot 40i.\n\nEste app não injeta código no Free Fire nem ativa mira automática.");
            card("Objetivo", "Praticar puxadas curtas, controlar o recuo e encontrar uma sensibilidade confortável.");
            button("Abrir treino de capa", () -> show("Treino de capa"));
            button("Ver otimização", () -> show("Desempenho"));
        } else if(page.equals("Treino de capa")) {
            card("TREINO DE PRECISÃO", "Faça 3 séries de 10 tentativas no campo de treino. Comece mirando no peito e arraste o dedo para cima com um movimento curto e controlado.");
            final TextView timer = new TextView(this); timer.setText("Sessão: 60 segundos"); timer.setTextColor(cyan); timer.setTextSize(20); timer.setPadding(0,18,0,18); content.addView(timer);
            button("Iniciar contagem de 60 s", () -> {
                timer.setText("Treino iniciado — concentre-se no movimento curto.");
                new android.os.CountDownTimer(60000,1000) {
                    public void onTick(long ms) { timer.setText("Tempo restante: " + (ms/1000) + " s"); }
                    public void onFinish() { timer.setText("Tempo concluído! Registe mentalmente quantas capas acertou."); }
                }.start();
            });
            card("Técnica", "• Use rajadas curtas, não arraste demasiado.\n• Mantenha a mira na altura do pescoço/peito superior.\n• Repita com a mesma arma e distância.\n• Ajuste apenas uma configuração de cada vez.");
        } else if(page.equals("Desempenho")) {
            card("OTIMIZAÇÃO SEGURA", "1. Feche aplicações em segundo plano antes de jogar.\n2. Ative o modo Jogo/Desempenho do XOS, se disponível.\n3. Use gráficos Suave e FPS Alto se o jogo estiver estável.\n4. Evite jogar enquanto o telefone carrega se aquecer muito.\n5. Mantenha espaço livre e atualize o jogo.");
            button("Abrir definições Android", () -> { try { startActivity(new android.content.Intent(android.provider.Settings.ACTION_SETTINGS)); } catch(Exception e) {} });
            card("Nota", "O painel não consegue aumentar FPS por software nem limpar RAM de outras apps sem permissões especiais. O resultado depende da temperatura, rede e definições do jogo.");
        } else {
            card("SENSIBILIDADE — PONTO DE PARTIDA", "Estes valores são apenas sugestões para testar. Não são aplicados automaticamente ao Free Fire; ajuste-os nas definições do próprio jogo.");
            slider("Geral", 90); slider("Ponto vermelho",85); slider("Mira 2x",80); slider("Mira 4x",75); slider("Olhadinha",70);
            card("Como ajustar", "Se passar por cima da cabeça, reduza 3–5 pontos. Se a mira não subir o suficiente, aumente 3–5 pontos. Teste cada alteração durante algumas partidas.");
        }
    }
    void slider(String label, int initial) {
        TextView title = new TextView(this); title.setText(label + ": " + initial); title.setTextColor(Color.WHITE); title.setTextSize(16); content.addView(title);
        SeekBar s = new SeekBar(this); s.setMax(100); s.setProgress(initial); s.setProgressTintList(android.content.res.ColorStateList.valueOf(green)); s.setThumbTintList(android.content.res.ColorStateList.valueOf(cyan));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seek, int value, boolean user) { title.setText(label + ": " + value); }
            public void onStartTrackingTouch(SeekBar seek) {}
            public void onStopTrackingTouch(SeekBar seek) {}
        }); content.addView(s);
    }
}
